from .topsis import main

__all__ = ["main"]
